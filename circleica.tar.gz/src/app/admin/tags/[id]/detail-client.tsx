"use client"

import { Card } from "@/components/ui/card"
import { ConfirmDialog } from "@/components/ui/confirm-dialog"
import { EmptyState } from "@/components/ui/empty-state"
import { Loader2, Pencil, Plus, Search, Tag, Trash2, X } from "lucide-react"
import { TAG_PRESET_COLORS } from "@/lib/tag-colors"
import { useEffect, useMemo, useRef, useState } from "react"
import { toast } from "sonner"
import { apiFetchSafe } from "@/lib/api-client"

/* ──────────────────── 类型 ──────────────────── */

interface TagItem {
  id: string
  name: string
  color: string
  gameCount: number
  description?: string | null
  groupId?: string | null
  sortOrder?: number
  isVisible?: boolean
}

interface GroupInfo {
  id: string
  name: string
  description: string
  color: string
  positions: string[]
  isPreset?: boolean
}

interface AllGroup {
  id: string
  name: string
  color: string
}

/* ──────────────────── 颜色选择器 ──────────────────── */

function ColorPicker({ value, onChange }: { value: string; onChange: (c: string) => void }) {
  const [hexInput, setHexInput] = useState(value)

  function handleHexChange(v: string) {
    setHexInput(v)
    if (/^#[0-9a-fA-F]{6}$/.test(v)) onChange(v)
  }

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-2">
        {TAG_PRESET_COLORS.map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => { setHexInput(c); onChange(c) }}
            className={`h-7 w-7 rounded-full transition-all cursor-pointer ${
              value.toLowerCase() === c.toLowerCase()
                ? "ring-2 ring-primary ring-offset-2 ring-offset-background scale-110"
                : "hover:scale-110"
            }`}
            style={{ background: c }}
          />
        ))}
      </div>
      <div className="flex items-center gap-3">
        <input type="color" value={value} onChange={(e) => { setHexInput(e.target.value); onChange(e.target.value) }} className="h-8 w-8 rounded-lg cursor-pointer border-0 bg-transparent" />
        <input type="text" value={hexInput} onChange={(e) => handleHexChange(e.target.value)} placeholder="#000000" className="w-28 rounded-lg border-2 border-input bg-transparent px-3 py-2 text-xs text-foreground font-mono outline-none transition-[border-radius,border-color] duration-300 ease-out focus:rounded-none focus:border-primary" />
        <div className="h-6 w-6 rounded-full ring-1 ring-border" style={{ background: value }} />
      </div>
    </div>
  )
}

/* ──────────────────── 主组件 ──────────────────── */

export function TagGroupDetailClient({
  group,
  tags: initialTags,
  allGroups,
}: {
  group: GroupInfo
  tags: TagItem[]
  allGroups: AllGroup[]
}) {
  const [tags, setTags] = useState(initialTags)
  const [searchQuery, setSearchQuery] = useState("")
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState("")

  // 新建标签
  const [showCreate, setShowCreate] = useState(false)
  const [newTagName, setNewTagName] = useState("")
  const [newTagColor, setNewTagColor] = useState(group.color || TAG_PRESET_COLORS[0])

  // 编辑标签
  const [editingTag, setEditingTag] = useState<string | null>(null)
  const [editName, setEditName] = useState("")
  const [editDesc, setEditDesc] = useState("")
  const [editColor, setEditColor] = useState("")
  const [editGroupId, setEditGroupId] = useState("")
  const [editSortOrder, setEditSortOrder] = useState(0)
  const [editVisible, setEditVisible] = useState(true)
  const editPanelRef = useRef<HTMLDivElement>(null)

  // 删除标签
  const [deletingTag, setDeletingTag] = useState<TagItem | null>(null)

  // 点击外部关闭编辑面板
  useEffect(() => {
    if (!editingTag) return
    function handleClick(e: PointerEvent) {
      if (editPanelRef.current && !editPanelRef.current.contains(e.target as Node)) {
        setEditingTag(null)
      }
    }
    document.addEventListener("pointerdown", handleClick)
    return () => document.removeEventListener("pointerdown", handleClick)
  }, [editingTag])

  // 过滤
  const filteredTags = useMemo(() => {
    if (!searchQuery.trim()) return tags
    const q = searchQuery.toLowerCase()
    return tags.filter((t) => t.name.toLowerCase().includes(q))
  }, [tags, searchQuery])

  // 该标签是否可管理（编辑/删除）：
  // - 首页卡片标签组 / 资源标签组由前台或专用管理页控制，不在此编辑
  // - resource: 前缀为设置驱动的伪标签，不可单独编辑删除
  const canManageTag = (tag: TagItem) =>
    group.id !== "preset_home_card" &&
    group.id !== "preset_resource_tab" &&
    !tag.id.startsWith("resource:")

  /* ── CRUD ── */

  async function handleCreateTag() {
    if (!newTagName.trim()) return
    setSaving(true)
    setError("")
    try {
      const { ok, data, error } = await apiFetchSafe<any>("/api/admin/tags", {
        method: "POST",
        body: {
          name: newTagName.trim(),
          color: newTagColor,
          groupId: group.id,
          sortOrder: 0,
          isVisible: true,
        },
      })
      if (!ok) { setError(error ?? "创建失败"); setSaving(false); return }
      // apiFetchSafe 的 data 是完整响应体，新建的标签实体在 data.data
      const created = (data as any)?.data ?? data
      setTags((prev) => [...prev, { ...created, gameCount: 0 }].sort((a, b) => a.name.localeCompare(b.name)))
      setNewTagName("")
      setShowCreate(false)
      toast.success("标签创建成功")
    } catch { setError("网络错误") }
    setSaving(false)
  }

  function openEdit(tag: TagItem) {
    setEditingTag(tag.id)
    setEditName(tag.name)
    setEditDesc(tag.description ?? "")
    setEditColor(tag.color)
    setEditGroupId(tag.groupId ?? "")
    setEditSortOrder(tag.sortOrder ?? 0)
    setEditVisible(tag.isVisible !== false)
  }

  async function handleUpdateTag() {
    if (!editingTag || !editName.trim()) return
    setSaving(true)
    setError("")
    try {
      const { ok, data, error } = await apiFetchSafe<any>(`/api/admin/tags/${editingTag}`, {
        method: "PUT",
        body: {
          name: editName.trim(),
          description: editDesc,
          color: editColor,
          groupId: editGroupId || group.id,
          sortOrder: editSortOrder,
          isVisible: editVisible,
        },
      })
      if (!ok) { setError(error ?? "更新失败"); setSaving(false); return }
      // 更新后的标签实体在 data.data
      const updated = (data as any)?.data ?? data
      if (updated.groupId && updated.groupId !== group.id) {
        setTags((prev) => prev.filter((t) => t.id !== editingTag))
        toast.success("已移动到其他标签组")
      } else {
        setTags((prev) =>
          prev.map((t) =>
            t.id === editingTag
              ? { ...t, name: updated.name, color: updated.color, description: updated.description, groupId: updated.groupId, sortOrder: updated.sortOrder, isVisible: updated.isVisible }
              : t
          )
        )
        toast.success("已保存")
      }
      setEditingTag(null)
    } catch { setError("网络错误") }
    setSaving(false)
  }

  async function handleDeleteTag() {
    if (!deletingTag) return
    setSaving(true)
    setError("")
    try {
      const { ok, error } = await apiFetchSafe(`/api/admin/tags/${deletingTag.id}`, { method: "DELETE" })
      if (!ok) { setError(error ?? "删除失败"); setSaving(false); return }
      setTags((prev) => prev.filter((t) => t.id !== deletingTag.id))
      setDeletingTag(null)
      toast.success("标签已删除")
    } catch { setError("网络错误") }
    setSaving(false)
  }

  const inputCls = "w-full rounded-lg border-2 border-input bg-transparent px-3 py-2.5 text-xs text-foreground placeholder:text-muted-foreground/50 outline-none transition-[border-radius,border-color] duration-300 ease-out focus:rounded-none focus:border-primary"

  return (
    <div className="space-y-5">
      {/* ── 顶部卡片 ── */}
      <Card size="comfortable" radius="xl">
        {!group.isPreset && (
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={() => setShowCreate(!showCreate)}
              className="flex items-center gap-1.5 rounded-lg bg-primary text-primary-foreground px-3 py-1.5 text-xs font-medium hover:opacity-90 transition-all cursor-pointer"
            >
              {showCreate ? <X className="h-3.5 w-3.5" /> : <Plus className="h-3.5 w-3.5" />}
              {showCreate ? "收起" : "新建标签"}
            </button>
          </div>
        )}

        {/* 搜索 */}
        <div className="relative max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="搜索标签…" aria-label="搜索标签"
            className="rounded-lg border-2 border-input bg-transparent pl-9 pr-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground outline-none transition-[border-radius,border-color] duration-300 ease-out focus:rounded-none focus:border-primary w-full"
          />
        </div>
      </Card>

      {error && (
        <div className="rounded-lg bg-red-500/10 px-3 py-2 text-xs text-red-400 ring-1 ring-red-500/20">{error}</div>
      )}

      {/* ── 新建标签表单 ── */}
      {showCreate && (
        <Card size="comfortable" radius="xl" className="space-y-4">
          <h3 className="text-sm font-semibold text-foreground">新建标签</h3>
          <input
            value={newTagName}
            onChange={(e) => setNewTagName(e.target.value)}
            placeholder="输入标签名称"
            className={inputCls}
            autoFocus
            onKeyDown={(e) => { if (e.key === "Enter") handleCreateTag(); if (e.key === "Escape") setShowCreate(false) }}
          />
          <ColorPicker value={newTagColor} onChange={setNewTagColor} />
          <div className="flex gap-2">
            <button
              onClick={handleCreateTag}
              disabled={saving || !newTagName.trim()}
              className="flex items-center gap-1.5 rounded-lg bg-primary text-primary-foreground px-4 py-2 text-xs font-medium hover:opacity-90 transition-all disabled:opacity-50 cursor-pointer"
            >
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
              创建标签
            </button>
            <button
              onClick={() => setShowCreate(false)}
              className="rounded-lg bg-secondary px-4 py-2 text-xs text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
            >
              取消
            </button>
          </div>
        </Card>
      )}

      {/* ── 标签列表（副站卡片样式） ── */}
      {filteredTags.length === 0 ? (
        <EmptyState
          icon={Tag}
          title={searchQuery ? "没有找到匹配的标签" : "该标签组暂无标签"}
          bordered
        />
      ) : (
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {filteredTags.map((tag) => (
            <div key={tag.id} className="group relative">
              {/* 标签卡片：左上颜色点+名字，下方关联作品，右下编辑/删除 */}
              <div className="flex flex-col rounded-xl border border-border bg-card p-3 transition-colors hover:border-[color:var(--admin-accent,var(--primary))]">
                <div className="flex items-center gap-2">
                  <span
                    className="inline-block h-2.5 w-2.5 shrink-0 rounded-full ring-1 ring-border"
                    style={{ background: tag.color || group.color }}
                  />
                  <span className="block min-w-0 flex-1 truncate font-medium text-foreground" title={tag.name}>
                    {tag.name}
                  </span>
                  {tag.isVisible === false && (
                    <span className="shrink-0 rounded bg-secondary px-1 py-0.5 text-micro text-muted-foreground">隐藏</span>
                  )}
                </div>
                {tag.description && (
                  <p className="mt-1 truncate text-xs text-muted-foreground">{tag.description}</p>
                )}
                <div className="mt-2 flex flex-wrap items-center justify-between gap-2 border-t border-border pt-2">
                  <span className="text-xs text-muted-foreground">关联作品 {tag.gameCount}</span>
                  {canManageTag(tag) && (
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={(e) => { e.stopPropagation(); openEdit(tag) }}
                        title="编辑"
                        className="flex h-7 w-7 items-center justify-center rounded-md text-muted-foreground ring-1 ring-border transition-all hover:bg-accent hover:text-foreground cursor-pointer"
                      >
                        <Pencil className="h-3 w-3" />
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); setDeletingTag(tag) }}
                        title="删除"
                        className="flex h-7 w-7 items-center justify-center rounded-md text-muted-foreground ring-1 ring-border transition-all hover:bg-red-500/10 hover:text-red-400 cursor-pointer"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* 内联编辑面板 */}
              {editingTag === tag.id && (
                <Card ref={editPanelRef} size="default" radius="xl" className="mt-2 shadow-3 space-y-3">
                  <div className="flex gap-2">
                    <input
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      placeholder="标签名称"
                      className="flex-1 rounded-lg border-2 border-input bg-transparent px-3 py-2.5 text-xs text-foreground outline-none transition-[border-radius,border-color] duration-300 ease-out focus:rounded-none focus:border-primary"
                      autoFocus
                    />
                    <select
                      value={editGroupId}
                      onChange={(e) => setEditGroupId(e.target.value)}
                      className="w-32 shrink-0 rounded-lg border-2 border-input bg-transparent px-2 py-2.5 text-xs text-foreground outline-none transition-[border-radius,border-color] duration-300 ease-out focus:rounded-none focus:border-primary"
                    >
                      {allGroups.map((g) => (
                        <option key={g.id} value={g.id}>{g.name}</option>
                      ))}
                    </select>
                  </div>
                  <input
                    value={editDesc}
                    onChange={(e) => setEditDesc(e.target.value)}
                    placeholder="标签描述（可选）"
                    className="w-full rounded-lg border-2 border-input bg-transparent px-3 py-2.5 text-xs text-foreground outline-none transition-[border-radius,border-color] duration-300 ease-out focus:rounded-none focus:border-primary"
                  />
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={editSortOrder}
                      onChange={(e) => setEditSortOrder(Number(e.target.value))}
                      title="排序值"
                      className="w-16 rounded-lg border-2 border-input bg-transparent px-2 py-2.5 text-xs text-foreground outline-none transition-[border-radius,border-color] duration-300 ease-out focus:rounded-none focus:border-primary"
                    />
                    <button
                      type="button"
                      onClick={() => setEditVisible(!editVisible)}
                      className={`rounded-lg px-3 py-2 text-xs ring-1 ring-border transition-colors cursor-pointer ${
                        editVisible ? "bg-primary/10 text-primary" : "bg-secondary text-muted-foreground"
                      }`}
                    >
                      {editVisible ? "可见" : "隐藏"}
                    </button>
                  </div>
                  <ColorPicker value={editColor} onChange={setEditColor} />
                  <div className="flex items-center gap-2 pt-1">
                    <button
                      onClick={handleUpdateTag}
                      disabled={saving || !editName.trim()}
                      className="flex items-center gap-1.5 rounded-lg bg-primary px-4 py-2 text-xs font-medium text-primary-foreground hover:opacity-90 transition-all disabled:opacity-50 cursor-pointer"
                    >
                      {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : null}
                      保存
                    </button>
                    <button
                      onClick={() => setEditingTag(null)}
                      className="rounded-lg bg-secondary px-4 py-2 text-xs text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
                    >
                      取消
                    </button>
                  </div>
                </Card>
              )}
            </div>
          ))}
        </div>
      )}

      {/* 删除确认 */}
      <ConfirmDialog
        open={!!deletingTag}
        onOpenChange={(v) => { if (!v) setDeletingTag(null) }}
        title="删除标签"
        description={`确定删除标签「${deletingTag?.name ?? ""}」？关联的标签关系将一并清除。`}
        confirmText="删除"
        variant="destructive"
        onConfirm={handleDeleteTag}
      />
    </div>
  )
}
