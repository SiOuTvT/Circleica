import { AdminPageSkeleton } from "@/components/admin/admin-page-skeleton"

export default function Loading() {
  return <AdminPageSkeleton rows={5} />
}
