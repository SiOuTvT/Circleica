"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ImageUpload } from "@/components/image-upload"
import { ConfirmDialog } from "@/components/ui/confirm-dialog"
import { Textarea } from "@/components/ui/textarea"
import { AdminPageContainer } from "@/components/admin-page-container"
import { EmptyState } from "@/components/ui/empty-state"
import { AdminTable, type AdminTableColumn } from "@/components/admin/admin-table"
import { useUnsavedChanges } from "@/hooks/use-unsaved-changes"
import { cn, withLabelableId } from "@/lib/utils"
import { Award, Edit2, Loader2, Plus, Save, Trash2, X } from "lucide-react"
import Image from "next/image"
import { useCallback, useEffect, useState, useId } from "react"
import { toast } from "sonner"
import { api, apiFetchSafe } from "@/lib/api-client"

interface Achievement {
  id: string
  name: string
  description: string
  icon: string
  characterImage: string
  category: string
  conditionType: string
  conditionTarget: number
  points: number
  hidden: boolean
  isActive: boolean
  unlockCount: number
  createdAt: string
}

const CONDITION_TYPES = [
  { value: "favorite_count", label: "收藏数" },
  { value: "comment_count", label: "评论数" },
  { value: "checkin_count", label: "签到天数" },
  { value: "checkin_streak", label: "连续签到天数" },
  { value: "forum_post_count", label: "论坛发帖数" },
  { value: "forum_like_received", label: "论坛被点赞数" },
  { value: "register_days", label: "注册天数" },
]

const CATEGORIES = [
  { value: "general", label: "通用" },
  { value: "collection", label: "收藏" },
  { value: "community", label: "社区" },
  { value: "loyalty", label: "忠诚" },
  { value: "special", label: "特殊" },
]

const inputCls = "w-full rounded-xl border-2 border-input bg-transparent px-4 py-3 text-[15px] text-foreground placeholder:text-muted-foreground/50 outline-none transition-[border-radius,border-color] duration-300 ease-out focus:rounded-none focus:border-primary"

export default function AdminAchievementsPage() {
  const [achievements, setAchievements] = useState<Achievement[]>([])
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState<Partial<Achievement> | null>(null)
  const [saving, setSaving] = useState(false)

  useUnsavedChanges(editing !== null)
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const j = await api.get<any>("/api/admin/achievements")
      setAchievements(Array.isArray(j) ? j : j.data ?? [])
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  async function handleSave() {
    if (!editing?.name?.trim()) { toast.error("名称不能为空"); return }
    if (!editing?.conditionType) { toast.error("请选择条件类型"); return }
    setSaving(true)
    try {
      const isEdit = editing.id
      const url = isEdit ? `/api/admin/achievements/${editing.id}` : "/api/admin/achievements"
      if (isEdit) await api.put(url, editing)
      else await api.post(url, editing)
      toast.success(isEdit ? "已更新" : "已创建")
      setEditing(null)
      load()
    } catch (e) {
      // api.put/post 抛 ApiError：显示后端返回的具体原因（如校验失败、权限不足）
      toast.error(e instanceof Error ? e.message : "保存失败，请重试")
    } finally { setSaving(false) }
  }

  async function handleDelete(id: string) {
    const { ok } = await apiFetchSafe(`/api/admin/achievements/${id}`, { method: "DELETE" })
    if (ok) { toast.success("已删除"); load() }
  }

  function startCreate() {
    setEditing({
      name: "", description: "", icon: "", characterImage: "",
      category: "general", conditionType: "favorite_count",
      conditionTarget: 1, points: 10, hidden: true, isActive: true,
    })
  }

  const achievementColumns: AdminTableColumn<Achievement>[] = [
    {
      key: "name",
      header: "成就",
      cell: (ach) => (
        <div className="flex items-center gap-2.5">
          {ach.icon ? (
            <Image src={ach.icon} alt="" width={32} height={32} className="h-8 w-8 rounded-lg" unoptimized />
          ) : (
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-500/10">
              <Award className="h-4 w-4 text-amber-400" />
            </div>
          )}
          <div>
            <p className="font-medium text-foreground">{ach.name}</p>
            <p className="text-xs text-muted-foreground truncate max-w-[200px]">{ach.description}</p>
          </div>
        </div>
      ),
    },
    {
      key: "condition",
      header: "条件",
      cell: (ach) => (
        <span className="text-muted-foreground">
          {CONDITION_TYPES.find((c) => c.value === ach.conditionType)?.label ?? ach.conditionType}
          {" ≥ "}
          {ach.conditionTarget}
        </span>
      ),
    },
    {
      key: "points",
      header: "积分",
      cell: (ach) => <span className="text-amber-400 font-medium">{ach.points}</span>,
    },
    {
      key: "unlockCount",
      header: "解锁数",
      cell: (ach) => <span className="text-muted-foreground">{ach.unlockCount}</span>,
    },
    {
      key: "status",
      header: "状态",
      cell: (ach) => (
        <div className="flex items-center gap-2">
          <span className={cn("inline-block h-2 w-2 rounded-full", ach.isActive ? "bg-emerald-400" : "bg-muted-foreground")} />
          <span className="text-xs text-muted-foreground">{ach.isActive ? "启用" : "禁用"}</span>
          {ach.hidden && <span className="rounded bg-muted-foreground/20 px-1.5 py-0.5 text-micro text-muted-foreground">隐藏</span>}
        </div>
      ),
    },
    {
      key: "actions",
      header: "操作",
      align: "right",
      cell: (ach) => (
        <div className="flex items-center justify-end gap-1">
          <button
            onClick={() => setEditing(ach)}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors"
          >
            <Edit2 className="h-4 w-4" />
          </button>
          <button
            onClick={() => setDeleteTarget(ach.id)}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-red-500/10 hover:text-red-400 transition-colors"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      ),
    },
  ]

  if (loading) {
    return (
      <AdminPageContainer
        eyebrow="ACHIEVEMENTS"
        title="成就管理"
        description="管理用户可解锁的成就"
      >
        <Card size="compact" radius="xl" className="overflow-hidden">
          <div className="p-4 space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="h-14 animate-pulse rounded bg-muted" />
            ))}
          </div>
        </Card>
      </AdminPageContainer>
    )
  }

  return (
    <AdminPageContainer
      eyebrow="ACHIEVEMENTS"
      title="成就管理"
      description="管理用户可解锁的成就"
      actions={
        <Button onClick={startCreate}>
          <Plus className="h-4 w-4" strokeWidth={2} />
          新建成就
        </Button>
      }
    >
      {/* 编辑表单 */}
      {editing && (
        <Card size="comfortable" radius="xl">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-semibold text-foreground">{editing.id ? "编辑成就" : "新建成就"}</h2>
            <button onClick={() => setEditing(null)} className="text-muted-foreground hover:text-foreground"><X className="h-5 w-5" /></button>
          </div>

          <div className="flex flex-col gap-5 md:flex-row">
            {/* 左侧：图片上传 */}
            <div className="flex gap-4 shrink-0">
              <div className="w-[100px]">
                <label className="mb-1.5 block text-sm font-medium text-foreground">图标</label>
                <ImageUpload
                  value={editing.icon ?? ""}
                  onChange={(url) => setEditing({ ...editing, icon: url })}
                  aspectRatio={1}
                  shape="rounded"
                  placeholder="上传图标"
                />
              </div>
              <div className="w-[120px]">
                <label className="mb-1.5 block text-sm font-medium text-foreground">解锁立绘</label>
                <ImageUpload
                  value={editing.characterImage ?? ""}
                  onChange={(url) => setEditing({ ...editing, characterImage: url })}
                  aspectRatio={3 / 4}
                  shape="rounded"
                  placeholder="上传立绘"
                />
              </div>
            </div>

            {/* 右侧：表单 */}
            <div className="flex-1 space-y-3 min-w-0">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Field label="名称"><input value={editing.name ?? ""} onChange={(e) => setEditing({ ...editing, name: e.target.value })} className={inputCls} placeholder="成就名称" /></Field>
                <Field label="分类"><select value={editing.category ?? "general"} onChange={(e) => setEditing({ ...editing, category: e.target.value })} className={inputCls}>{CATEGORIES.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}</select></Field>
                <Field label="条件类型"><select value={editing.conditionType ?? "favorite_count"} onChange={(e) => setEditing({ ...editing, conditionType: e.target.value })} className={inputCls}>{CONDITION_TYPES.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}</select></Field>
                <Field label="目标值"><input type="number" value={editing.conditionTarget ?? 1} onChange={(e) => setEditing({ ...editing, conditionTarget: Number(e.target.value) })} className={inputCls} min={1} /></Field>
                <Field label="积分"><input type="number" value={editing.points ?? 10} onChange={(e) => setEditing({ ...editing, points: Number(e.target.value) })} className={inputCls} min={1} /></Field>
                <div className="col-span-2"><Field label="描述"><Textarea variant="filled" value={editing.description ?? ""} onChange={(e) => setEditing({ ...editing, description: e.target.value })} className="min-h-[56px] resize-y text-sm" placeholder="成就描述" /></Field></div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-4">
                  <label className="flex items-center gap-2 text-sm text-foreground"><input type="checkbox" checked={editing.hidden !== false} onChange={(e) => setEditing({ ...editing, hidden: e.target.checked })} className="rounded" />隐藏</label>
                  <label className="flex items-center gap-2 text-sm text-foreground"><input type="checkbox" checked={editing.isActive !== false} onChange={(e) => setEditing({ ...editing, isActive: e.target.checked })} className="rounded" />启用</label>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => setEditing(null)} className="rounded-lg px-3 py-1.5 text-sm text-muted-foreground hover:bg-secondary hover:text-foreground">取消</button>
                  <button onClick={handleSave} disabled={saving} className="flex items-center gap-1.5 rounded-lg bg-primary px-4 py-1.5 text-sm font-semibold text-primary-foreground hover:opacity-90 disabled:opacity-60">
                    {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}保存
                  </button>
                </div>
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* 列表 */}
      <div className="overflow-x-auto">
        <AdminTable
          columns={achievementColumns}
          rows={achievements}
          getRowKey={(ach) => ach.id}
          empty={<EmptyState icon={Award} title="暂无成就" description="点击上方「新建成就」创建第一个" />}
        />
      </div>

      <ConfirmDialog
        open={!!deleteTarget}
        onOpenChange={(open) => { if (!open) setDeleteTarget(null) }}
        title="删除成就"
        description="确定删除此成就？所有用户的解锁记录也会被删除。"
        variant="destructive"
        confirmText="删除"
        onConfirm={() => { if (deleteTarget) handleDelete(deleteTarget) }}
      />
    </AdminPageContainer>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  const id = useId()
  return <div><label htmlFor={id} className="mb-1.5 block text-sm font-medium text-foreground">{label}</label>{withLabelableId(children, id)}</div>
}
