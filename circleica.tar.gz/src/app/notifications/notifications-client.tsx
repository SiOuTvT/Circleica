"use client"

import { ConfirmDialog } from "@/components/ui/confirm-dialog"
import { EmptyState } from "@/components/ui/empty-state"
import { timeAgo } from "@/lib/time-ago"
import { cn } from "@/lib/utils"
import { logger } from "@/lib/logger"
import { Bell, CheckCheck, Trash2 } from "lucide-react"
import { toast } from "sonner"
import Image from "next/image"
import Link from "next/link"
import { useCallback, useEffect, useRef, useState } from "react"
import { api } from "@/lib/api-client"

interface NotificationItem {
  id: string
  type: string
  targetType: string
  targetId: string
  isRead: boolean
  createdAt: string
  postId?: string | null
  actor: {
    id: string
    serialId: number | null
    username: string
    avatar: string
  }
  targetGame?: { id: string; title: string } | null
}

const TYPE_CONFIG: Record<string, {
  icon: typeof Bell
  text: (actor: string, gameTitle?: string) => string
  subtitle?: (actor: string, gameTitle?: string) => string
  href: (targetType: string, targetId: string, postId?: string | null) => string
}> = {
  forum_post_like: {
    icon: Bell,
    text: (actor) => `${actor} 赞了你的帖子`,
    href: (_targetType, id) => `/forum/${id}`,
  },
  forum_comment_like: {
    icon: Bell,
    text: (actor) => `${actor} 赞了你的评论`,
    href: (_targetType, _id, postId) => postId ? `/forum/${postId}` : "/forum",
  },
  forum_comment_new: {
    icon: Bell,
    text: (actor) => `${actor} 评论了你的帖子`,
    href: (_targetType, id) => `/forum/${id}`,
  },
  follow: {
    icon: Bell,
    text: (actor) => `${actor} 关注了你`,
    href: (_targetType, id) => `/user/${id}`,
  },
  private_message: {
    icon: Bell,
    text: (actor) => `${actor} 给你发来一条私信`,
    href: (_targetType, _id) => "/messages",
  },
  resource_reported: {
    icon: Bell,
    text: (actor, gameTitle) =>
      gameTitle
        ? `${actor} 反馈了「${gameTitle}」中你的某条资源链接已失效，请检查并更新。`
        : `${actor} 反馈了你的某条资源链接已失效，请检查并更新。`,
    href: (_targetType, id) => `/games/${id}?tab=resource`,
  },
  game_resource_new: {
    icon: Bell,
    text: (_actor, gameTitle) =>
      gameTitle
        ? `你收藏的「${gameTitle}」有新资源上传了`
        : `你收藏的游戏有新资源上传了`,
    subtitle: (actor, gameTitle) =>
      gameTitle
        ? `${actor} 在「${gameTitle}」发布了新资源`
        : `${actor} 发布了新资源`,
    href: (_targetType, id) => `/games/${id}?tab=resource`,
  },
}

export default function NotificationsClient({
  initialNotifications,
  initialUnreadCount,
}: {
  initialNotifications: NotificationItem[]
  initialUnreadCount: number
}) {
  const [notifications, setNotifications] = useState(initialNotifications)
  const [unreadCount, setUnreadCount] = useState(initialUnreadCount)
  const [nextCursor, setNextCursor] = useState<string | null>(null)
  const [loadingMore, setLoadingMore] = useState(false)
  const [showClearConfirm, setShowClearConfirm] = useState(false)
  const [showReadConfirm, setShowReadConfirm] = useState(false)
  const [singleDeleteId, setSingleDeleteId] = useState<string | null>(null)

  // 进入页面时标记所有为已读（使用 ref 保证仅执行一次，同时读取最新的 unreadCount）
  const hasMarkedAllRead = useRef(false)
  useEffect(() => {
    if (!hasMarkedAllRead.current && unreadCount > 0) {
      hasMarkedAllRead.current = true
      api.put("/api/notifications").then(() => {
        setUnreadCount(0)
        setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })))
      }).catch(() => {})
    }
  }, [unreadCount])

  const fetchMore = useCallback(async () => {
    if (!nextCursor || loadingMore) return
    setLoadingMore(true)
    try {
      // api.get 返回完整响应体 { success, data: { notifications, nextCursor } }，需解 data.data
      const data = await api.get<{ data?: { notifications?: NotificationItem[]; nextCursor?: string | null } }>(`/api/notifications?cursor=${nextCursor}`)
      const inner = data?.data
      setNotifications((prev) => [...prev, ...(inner?.notifications ?? [])])
      setNextCursor(inner?.nextCursor ?? null)
    } catch (err) { logger.api.warn("[NotificationsClient] fetchMore failed", { error: err instanceof Error ? err.message : String(err) }) }
    setLoadingMore(false)
  }, [nextCursor, loadingMore])

  async function markRead(ids: string[]) {
    try {
      await api.put("/api/notifications", { ids })
      setNotifications((prev) => prev.map((n) => ids.includes(n.id) ? { ...n, isRead: true } : n))
      setUnreadCount((c) => Math.max(0, c - ids.length))
    } catch { toast.error("标记已读失败，请稍后再试") }
  }

  async function markAllRead() {
    try {
      // 不传 ids → 后端走全量 markAllRead（未加载的页也一并标记，数据闭环）
      await api.put("/api/notifications", {})
      setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })))
      setUnreadCount(0)
    } catch { toast.error("全部已读失败，请稍后再试") }
  }

  async function deleteNotifications(ids: string[]) {
    try {
      await api.delete("/api/notifications", { body: { ids } })
      setNotifications((prev) => prev.filter((n) => !ids.includes(n.id)))
      setUnreadCount((c) => {
        const deletedUnread = notifications.filter(n => ids.includes(n.id) && !n.isRead).length
        return Math.max(0, c - deletedUnread)
      })
    } catch { toast.error("删除通知失败，请稍后再试") }
  }

  async function deleteRead() {
    const readIds = notifications.filter(n => n.isRead).map(n => n.id)
    if (readIds.length > 0) await deleteNotifications(readIds)
  }

  async function deleteAll() {
    try {
      await api.delete("/api/notifications", { body: {} })
      setNotifications([])
      setUnreadCount(0)
    } catch { toast.error("清空通知失败，请稍后再试") }
  }

  return (
    <div>
      {/* 标题（ArchiveHero 设计语言：主题色图标无灰底 + 英文 eyebrow + 大字标题） */}
      <header className="mb-6 flex flex-col gap-4">
        <div className="flex items-start gap-4">
          <div className="flex h-12 w-fit shrink-0 items-center justify-center text-primary">
            <Bell className="h-6 w-6 sm:h-7 sm:w-7" strokeWidth={2} aria-hidden />
          </div>
          {/* 文字列：eyebrow + 标题 + 描述共用图标右侧这一条左基准线（与 ArchiveHero 同源） */}
          <div className="min-w-0 flex-1">
            <p className="mb-1.5 text-xs font-medium uppercase tracking-[0.2em] text-muted-foreground">NOTIFICATIONS</p>
            <h1 className="font-heading text-xl font-bold leading-tight text-foreground sm:text-2xl">消息通知</h1>
            <p className="mt-2 max-w-prose text-sm leading-relaxed text-muted-foreground sm:text-[15px]">
              {unreadCount > 0 ? `${unreadCount} 条未读消息` : "暂无未读消息"}
            </p>
          </div>
        </div>
      </header>

      {/* 操作栏 */}
      {notifications.length > 0 && (
        <div className="flex gap-2 mb-4">
          <button
            onClick={markAllRead}
            className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium text-muted-foreground ring-1 ring-border hover:bg-accent hover:text-foreground transition-all"
          >
            <CheckCheck className="h-3.5 w-3.5" />
            全部已读
          </button>
          <button
            onClick={() => setShowReadConfirm(true)}
            className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium text-muted-foreground ring-1 ring-border hover:bg-accent hover:text-foreground transition-all"
          >
            <Trash2 className="h-3.5 w-3.5" />
            删除已读
          </button>
          <button
            onClick={() => setShowClearConfirm(true)}
            className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium text-muted-foreground ring-1 ring-border hover:text-red-400 hover:ring-red-500/30 transition-all ml-auto"
          >
            清空全部
          </button>
        </div>
      )}

      {/* 通知列表 */}
      <div className="space-y-1">
        {notifications.length === 0 ? (
          <EmptyState icon={Bell} title="暂无新通知" />
        ) : (
          notifications.map((n) => {
            const config = TYPE_CONFIG[n.type]
            if (!config) return null
            const href = config.href(n.targetType, n.targetId, n.postId)
            return (
              <Link
                key={n.id}
                href={href}
                onClick={() => { if (!n.isRead) markRead([n.id]) }}
                className={cn(
                  "group flex items-center gap-3 rounded-xl bg-card px-4 py-3 cursor-pointer",
                  "ring-1 ring-border/50 transition-all duration-200",
                  "hover:ring-primary/30 hover:bg-accent/30",
                  !n.isRead && "ring-primary/30 bg-primary/[0.04]"
                )}
              >
                {/* 头像 */}
                <div className="relative shrink-0">
                  {n.actor.avatar ? (
                    <Image
                      src={n.actor.avatar}
                      alt=""
                      width={40}
                      height={40}
                      className="rounded-full object-cover ring-1 ring-border/50"
                      unoptimized
                    />
                  ) : (
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary ring-1 ring-primary/20">
                      {n.actor.username[0]?.toUpperCase()}
                    </div>
                  )}
                  {!n.isRead && (
                    <span className="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full border-2 border-card bg-primary" />
                  )}
                </div>

                {/* 内容 */}
                <div className="min-w-0 flex-1">
                  <p className={cn("text-sm leading-relaxed", !n.isRead ? "text-foreground" : "text-foreground/80")}>{config.text(n.actor.username, n.targetGame?.title)}</p>
                  {config.subtitle && (
                    <p className="mt-0.5 text-xs text-muted-foreground">{config.subtitle(n.actor.username, n.targetGame?.title)}</p>
                  )}
                  <p className="mt-0.5 text-xs text-muted-foreground/70">{timeAgo(n.createdAt)}</p>
                </div>

                {/* 删除按钮 */}
                <button
                  onClick={(e) => { e.preventDefault(); e.stopPropagation(); setSingleDeleteId(n.id) }}
                  className="shrink-0 rounded-lg p-1.5 text-muted-foreground opacity-0 transition-all group-hover:opacity-100 hover:text-red-400"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </Link>
            )
          })
        )}
      </div>

      {/* 加载更多 */}
      {nextCursor && (
        <div className="mt-4 flex justify-center">
          <button
            onClick={fetchMore}
            disabled={loadingMore}
            className="rounded-lg px-4 py-2 text-sm text-muted-foreground ring-1 ring-border hover:bg-accent hover:text-foreground disabled:opacity-50 transition-all"
          >
            {loadingMore ? "加载中…" : "加载更多"}
          </button>
        </div>
      )}

      <ConfirmDialog
        open={showClearConfirm}
        onOpenChange={setShowClearConfirm}
        title="清空通知"
        description="确定要清空所有通知吗？删了就找不回来了。"
        variant="destructive"
        confirmText="清空"
        onConfirm={deleteAll}
      />
      <ConfirmDialog
        open={showReadConfirm}
        onOpenChange={setShowReadConfirm}
        title="清除已读通知"
        description="确定要清除所有已读通知吗？删了就找不回来了。"
        variant="destructive"
        confirmText="清除"
        onConfirm={() => { deleteRead(); setShowReadConfirm(false) }}
      />
      <ConfirmDialog
        open={singleDeleteId !== null}
        onOpenChange={(open) => { if (!open) setSingleDeleteId(null) }}
        title="删除通知"
        description="确定要删除这条通知吗？"
        variant="destructive"
        confirmText="删除"
        onConfirm={() => { if (singleDeleteId) { deleteNotifications([singleDeleteId]); setSingleDeleteId(null) } }}
      />
    </div>
  )
}
