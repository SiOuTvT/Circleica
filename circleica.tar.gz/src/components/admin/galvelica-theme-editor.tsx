"use client"

/**
 * 副站主题编辑器（完整版）——沿用主站 ThemeEditor 的预设/调色板/排版，
 * 但**数据绝对隔离**：全部写入 galvelica: 独立命名空间，绝不触碰主站 themeColor/themeRadius/…。
 * 预览为副站风格（--gal-accent 实时变色 + 圆角/阴影/着色变量），只作用副站作用域。
 */
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { THEME_PRESETS } from "@/lib/theme-presets"
import { Check, Database, FileText, Loader2, RotateCcw, Save } from "lucide-react"
import { useEffect, useState } from "react"
import { toast } from "sonner"
import type { GalvelicaThemeSettings } from "@/lib/site-settings"

function hexToRgb(hex: string): [number, number, number] {
  let h = hex.replace("#", "")
  if (h.length === 3) h = h.split("").map((c) => c + c).join("")
  const n = parseInt(h, 16)
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255]
}

/** 副站主题默认 = 主站旗舰「薄荷」（用户拍板：删铜绿，直接用薄荷） */
const DEFAULT_SETTINGS: GalvelicaThemeSettings = {
  themeColor: "#5FA8A0",
  themeRadius: 16,
  themeShadowIntensity: 50,
  themeAlpha: 15,
}

/** 副站色板 = 主站 10 套预设（沿用；默认薄荷在预设内） */
const GAL_PRESETS = THEME_PRESETS

interface Props {
  initialSettings: GalvelicaThemeSettings
  onSave: (settings: GalvelicaThemeSettings) => Promise<void>
}

export function GalvelicaThemeEditor({ initialSettings, onSave }: Props) {
  const [draft, setDraft] = useState<GalvelicaThemeSettings>(initialSettings)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  useEffect(() => { setDraft(initialSettings) }, [initialSettings])

  // 实时预览：把草稿值作用到「副站后台预览区」所在的临时作用域变量
  // （保存后由 GalvelicaShell SSR 注入 .galvelica-root，前台真正生效）
  useEffect(() => {
    const [r, g, b] = hexToRgb(draft.themeColor)
    const root = document.documentElement
    root.style.setProperty("--gal-accent", draft.themeColor)
    root.style.setProperty("--gal-accent-soft", `rgba(${r}, ${g}, ${b}, 0.14)`)
    root.style.setProperty("--gal-radius", `${draft.themeRadius}px`)
    root.style.setProperty("--gal-shadow-alpha", String(draft.themeShadowIntensity / 100))
    root.style.setProperty("--gal-alpha", `${draft.themeAlpha}%`)
  }, [draft])

  const hasChanges = JSON.stringify(draft) !== JSON.stringify(initialSettings)
  const [tr, tg, tb] = hexToRgb(draft.themeColor)
  const rounded = `${draft.themeRadius}px`

  function updateDraft(patch: Partial<GalvelicaThemeSettings>) {
    setDraft((prev) => ({ ...prev, ...patch }))
  }

  function handleReset() {
    setDraft(DEFAULT_SETTINGS)
  }

  async function handleSave() {
    setSaving(true)
    try {
      await onSave({ ...draft })
      setSaved(true)
      setTimeout(() => setSaved(false), 2500)
    } catch {
      toast.error("保存失败")
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="flex flex-col gap-8">
      {/* 操作栏（页面头已有标题与说明，这里只保留操作按钮，避免重复大标题） */}
      <div className="flex items-center justify-end gap-2">
        <Button variant="ghost" size="sm" onClick={handleReset}>
          <RotateCcw className="h-4 w-4 mr-1.5" /> 恢复默认
        </Button>
        <Button size="sm" onClick={handleSave} disabled={!hasChanges || saving}>
          {saving ? (
            <Loader2 className="h-4 w-4 animate-spin mr-1.5" />
          ) : saved ? (
            <Check className="h-4 w-4 mr-1.5" />
          ) : (
            <Save className="h-4 w-4 mr-1.5" />
          )}
          {saved ? "已保存" : "确认保存"}
        </Button>
      </div>

      <div className="grid gap-8 md:grid-cols-2">
        {/* 左侧：控件 */}
        <div className="flex flex-col gap-6">
          {/* 主题色预设（副站铜绿 + 主站 10 套，仅读取色值，数据仍写 galvelica: 命名空间） */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">🎨 主题颜色</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-5 gap-3 sm:grid-cols-5">
                {GAL_PRESETS.map((preset) => {
                  const isActive = draft.themeColor.toLowerCase() === preset.color.toLowerCase()
                  return (
                    <button
                      key={preset.name}
                      onClick={() => updateDraft({ themeColor: preset.color })}
                      className="flex flex-col items-center gap-2 rounded-xl p-2.5 transition-all"
                      style={{
                        border: `2px solid ${isActive ? draft.themeColor : "hsl(var(--border))"}`,
                        background: isActive ? `rgba(${tr},${tg},${tb},0.1)` : "transparent",
                      }}
                    >
                      <div className="relative">
                        <div
                          className="h-9 w-9 rounded-full"
                          style={{ backgroundColor: preset.color, boxShadow: "inset 0 2px 4px rgba(0,0,0,0.15)" }}
                        />
                        {isActive && (
                          <div className="absolute inset-0 flex items-center justify-center">
                            <Check className="h-4 w-4 text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.5)]" />
                          </div>
                        )}
                      </div>
                      <span className="text-xs font-medium text-foreground">{preset.label}</span>
                    </button>
                  )
                })}
              </div>
              {/* 自定义颜色 */}
              <div className="mt-4 flex items-center gap-4 border-t pt-4" style={{ borderColor: "hsl(var(--border))" }}>
                <label className="relative h-10 w-10 shrink-0 cursor-pointer overflow-hidden rounded-lg">
                  <div className="h-full w-full" style={{ backgroundColor: draft.themeColor }} />
                  <input
                    type="color"
                    value={draft.themeColor}
                    onChange={(e) => updateDraft({ themeColor: e.target.value })}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                </label>
                <div>
                  <p className="text-sm font-medium text-foreground">自定义颜色</p>
                  <code className="text-xs text-muted-foreground">{draft.themeColor}</code>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 圆角 */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">📐 圆角大小</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-foreground">圆角大小</span>
                <code className="text-sm font-semibold">{draft.themeRadius}px</code>
              </div>
              <input
                type="range" min={0} max={30} step={1}
                value={draft.themeRadius}
                onChange={(e) => updateDraft({ themeRadius: Number(e.target.value) })}
                className="w-full accent-[var(--gal-accent)]"
              />
              <p className="text-xs text-muted-foreground">0px = 直角，16px = 副站默认圆角，24px = 大圆角（仅副站卡片生效）</p>
            </CardContent>
          </Card>

          {/* 阴影强度 */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">🌫️ 阴影强度</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-foreground">阴影强度</span>
                <code className="text-sm font-semibold">{draft.themeShadowIntensity}%</code>
              </div>
              <input
                type="range" min={0} max={100} step={5}
                value={draft.themeShadowIntensity}
                onChange={(e) => updateDraft({ themeShadowIntensity: Number(e.target.value) })}
                className="w-full accent-[var(--gal-accent)]"
              />
              <p className="text-xs text-muted-foreground">控制副站卡片的阴影深度（仅副站生效）</p>
            </CardContent>
          </Card>

          {/* 背景着色透明度 */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">💧 背景着色</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-foreground">着色透明度</span>
                <code className="text-sm font-semibold">{draft.themeAlpha}%</code>
              </div>
              <input
                type="range" min={0} max={50} step={1}
                value={draft.themeAlpha}
                onChange={(e) => updateDraft({ themeAlpha: Number(e.target.value) })}
                className="w-full accent-[var(--gal-accent)]"
              />
              <p className="text-xs text-muted-foreground">副站标签/按钮等元素的背景着色深度（0% = 无着色）</p>
            </CardContent>
          </Card>
        </div>

        {/* 右侧：预览（副站风格） */}
        <div className="flex flex-col gap-6">
          {/* 实时预览 */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">👁️ 副站实时预览</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap gap-2">
                <Button size="sm" style={{ borderRadius: rounded, backgroundColor: draft.themeColor, color: "#fff" }}>副站按钮</Button>
                <Button size="sm" variant="secondary" style={{ borderRadius: rounded }}>次要按钮</Button>
                <Badge variant="outline" className="px-2.5" style={{ borderRadius: rounded, color: draft.themeColor, borderColor: `rgba(${tr},${tg},${tb},0.35)` }}>
                  副站标签
                </Badge>
                <Badge variant="outline" className="px-2.5" style={{ borderRadius: rounded, color: draft.themeColor, borderColor: `rgba(${tr},${tg},${tb},0.35)` }}>
                  档案徽章
                </Badge>
              </div>

              {/* 副站卡片预览（galvelica-card 观感） */}
              <div
                className="galvelica-card overflow-hidden border p-4"
                style={{ borderRadius: rounded, borderColor: `rgba(${tr},${tg},${tb},0.25)` }}
              >
                <div className="flex gap-4">
                  <div
                    className="h-16 w-16 shrink-0 rounded-lg"
                    style={{
                      borderRadius: Math.max(4, Math.round(draft.themeRadius * 0.6)),
                      background: `linear-gradient(135deg, rgba(${tr},${tg},${tb},0.35), rgba(${tr},${tg},${tb},0.1))`,
                    }}
                  />
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-foreground">作品卡片预览</p>
                    <p className="text-xs text-muted-foreground">圆角 {draft.themeRadius}px · 阴影 {draft.themeShadowIntensity}% · 着色 {draft.themeAlpha}%</p>
                    <div className="mt-2 flex gap-1.5">
                      <Badge variant="secondary" className="text-micro" style={{ borderRadius: Math.max(2, Math.round(draft.themeRadius * 0.4)) }}>ADV</Badge>
                      <Badge variant="secondary" className="text-micro" style={{ borderRadius: Math.max(2, Math.round(draft.themeRadius * 0.4)) }}>恋爱</Badge>
                    </div>
                  </div>
                </div>
              </div>

              {/* 着色百分比条（副站 --gal-accent 派生） */}
              <div className="flex gap-2">
                {[5, 10, 15, 20, 30].map((pct) => (
                  <div
                    key={pct}
                    className="flex flex-1 items-center justify-center rounded-lg py-2.5 font-mono text-xs"
                    style={{ backgroundColor: `rgba(${tr},${tg},${tb},${pct / 100})`, borderRadius: rounded }}
                  >
                    {pct}%
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 当前生效主题 */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2"><Database className="h-4 w-4" strokeWidth={2} /> 当前生效副站主题</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                <div className="flex items-center gap-2">
                  <div
                    className="h-5 w-5 rounded-full"
                    style={{ backgroundColor: initialSettings.themeColor, boxShadow: "inset 0 1px 2px rgba(0,0,0,0.15)" }}
                  />
                  <code className="text-xs text-muted-foreground">{initialSettings.themeColor}</code>
                </div>
                <span className="text-xs text-muted-foreground">圆角: <strong>{initialSettings.themeRadius}px</strong></span>
                <span className="text-xs text-muted-foreground">阴影: <strong>{initialSettings.themeShadowIntensity}%</strong></span>
                <span className="text-xs text-muted-foreground">着色: <strong>{initialSettings.themeAlpha}%</strong></span>
              </div>
              <p className="mt-3 text-xs text-muted-foreground">
                存储键：galvelica:themeColor / galvelica:themeRadius / galvelica:themeShadowIntensity / galvelica:themeAlpha —— 与主站 themeColor 等完全隔离。
              </p>
            </CardContent>
          </Card>

          {/* 待保存变更 */}
          {hasChanges && (
            <Card className="border-amber-500/30">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2"><FileText className="h-4 w-4" strokeWidth={2} /> 待保存变更</CardTitle>
              </CardHeader>
              <CardContent className="space-y-1.5">
                {draft.themeColor !== initialSettings.themeColor && (
                  <p className="text-sm">
                    颜色: <span className="line-through text-muted-foreground">{initialSettings.themeColor}</span> → <strong>{draft.themeColor}</strong>
                  </p>
                )}
                {draft.themeRadius !== initialSettings.themeRadius && (
                  <p className="text-sm">
                    圆角: <span className="line-through text-muted-foreground">{initialSettings.themeRadius}px</span> → <strong>{draft.themeRadius}px</strong>
                  </p>
                )}
                {draft.themeShadowIntensity !== initialSettings.themeShadowIntensity && (
                  <p className="text-sm">
                    阴影: <span className="line-through text-muted-foreground">{initialSettings.themeShadowIntensity}%</span> → <strong>{draft.themeShadowIntensity}%</strong>
                  </p>
                )}
                {draft.themeAlpha !== initialSettings.themeAlpha && (
                  <p className="text-sm">
                    着色: <span className="line-through text-muted-foreground">{initialSettings.themeAlpha}%</span> → <strong>{draft.themeAlpha}%</strong>
                  </p>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
